package com.cts.book.ticket.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.book.ticket.app.dao.TicketbookingDao;
import com.cts.book.ticket.app.entities.Ticket;

@Service
public class TicketBookingService {

	@Autowired
	private TicketbookingDao ticketbookingDao;

	public Ticket createTicket(Ticket ticket) {
		return ticketbookingDao.save(ticket);
	}

	public Ticket getTicketById(Integer ticketId) {
		return TicketbookingDao.findOne(ticketId);
	}

}
