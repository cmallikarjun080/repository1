package com.cts.book.ticket.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.book.ticket.app.entities.Ticket;
import com.cts.book.ticket.app.service.TicketBookingService;

@RestController
@RequestMapping(value = "/api/tickets")
public class TicketBookingController {

	@Autowired
	private TicketBookingService ticketBookingService;

	// create a resource to server
	@PostMapping(value = "/create")
	public Ticket createTicket(Ticket ticket) {
		return ticketBookingService.createTicket(ticket);
	}

	// read a resource from server
	@GetMapping(value = "/ticket/{ticketId}")
	public Ticket getTicketById(Integer ticketId) {
		return ticketBookingService.getTicketById(ticketId);

	}
}
