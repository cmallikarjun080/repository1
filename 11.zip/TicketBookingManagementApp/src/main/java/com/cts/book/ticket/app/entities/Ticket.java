package com.cts.book.ticket.app.entities;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ticket")
public class Ticket {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ticket_Id")
	private int ticket_Id;

	@Column(name = "passenger_name", nullable = false)
	private String passenger_Name;
	@Column(name = "booking_date")
	private Date booking_Date;
	@Column(name = "source_station")
	private String source_Station;
	@Column(name = "dest_station")
	private String dest_Station;

	public int getTicket_Id() {
		return ticket_Id;
	}

	public void setTicket_Id(int ticket_Id) {
		this.ticket_Id = ticket_Id;
	}

	public String getPassenger_Name() {
		return passenger_Name;
	}

	public void setPassenger_Name(String passenger_Name) {
		this.passenger_Name = passenger_Name;
	}

	public Date getBooking_Date() {
		return booking_Date;
	}

	public void setBooking_Date(Date booking_Date) {
		this.booking_Date = booking_Date;
	}

	public String getSource_Station() {
		return source_Station;
	}

	public void setSource_Station(String source_Station) {
		this.source_Station = source_Station;
	}

	public String getDest_Station() {
		return dest_Station;
	}

	public void setDest_Station(String dest_Station) {
		this.dest_Station = dest_Station;
	}

	@Override
	public String toString() {
		return "Ticket [ticket_Id=" + ticket_Id + ", passenger_Name=" + passenger_Name + ", booking_Date="
				+ booking_Date + ", source_Station=" + source_Station + ", dest_Station=" + dest_Station + "]";
	}

}
